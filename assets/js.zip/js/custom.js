// Header
$(function() {
    $(window).on("scroll", function() {
        if($(window).scrollTop() > 50) {
            $("header").addClass("header-active");
        } else {
            //remove the background property so it comes transparent again (defined in your css)
           $("header").removeClass("header-active");
        }
    });
});

// Cart-Popup
function myFunction() {
  document.getElementById("myPopup").classList.toggle("cartshow");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.popupbtn')) {
    var dropdowns = document.getElementsByClassName("popupbtn-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('cartshow')) {
        openDropdown.classList.remove('cartshow');
      }
    }
  }
}

// Gallery 
$(function () {
  "use strict";
    $('.gallery-image').slice(0, 12).show();
    $('#loadmore').on('click', function (e) {
        e.preventDefault();
        $('.gallery-image:hidden').slice(0, 4).slideDown();
        if ($('.gallery-image:hidden').length === 0) {
            $('#loadmore').replaceWith("<a id='nomore-image' class='serv-btn' href=''><span class='spanbtn'>No More</span></a>");
        }
    });
    // $('#top').on('click', function (e) {
    //     e.preventDefault();
    //     $('html, body').animate({
    //         scrollTop: 0
    //     }, 600);
    //     return false;
    // });
    // $(window).scroll(function () {
    //     if ($(this).scrollTop() > 50) {
    //         $('#top a').fadeIn();
    //     } else {
    //         $('#top a').fadeOut();
    //     }
    // });
});


// Blog
$(function () {
  "use strict";
    $('.blog-article').slice(0, 3).show();
    $('#loadmoreBlog').on('click', function (e) {
        e.preventDefault();
        $('.blog-article:hidden').slice(0, 2).slideDown();
        if ($('.blog-article:hidden').length === 0) {
            $('#loadmoreBlog').replaceWith("<a id='nomore-blog' class='serv-btn' href=''><span class='spanbtn'>No More</span></a>");
        }
    });
});

/*$('.inside_single_page').on('click', function (e) {
        e.preventDefault();
        console.log($(this).attr("data-id"));
        $.ajax({
           type: "POST",
           data: {info:info},
           url: "index.php",
           success: function(msg){
             $('.answer').html(msg);
           }
        });
    });*/

// Counter
$('.custom-count').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 4000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
});


    /*$('.inside_single_page').on('click', function (e) {
        e.preventDefault();
        console.log('usama');
    }*/
